<?php $__env->startSection('content'); ?>
<div class="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
    <h2 class="text-2xl font-bold text-gray-800 dark:text-white mb-4">Pesan dari Pengunjung</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="min-w-full text-left border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
        <thead class="bg-gray-100 dark:bg-gray-700">
            <tr>
                <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Nama</th>
                <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Email</th>
                <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Pesan</th>
                <th class="px-4 py-2 text-gray-700 dark:text-gray-300 text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-900 transition">
                    <td class="px-4 py-2 text-gray-800 dark:text-gray-200"><?php echo e($p->nama); ?></td>
                    <td class="px-4 py-2 text-gray-800 dark:text-gray-200"><?php echo e($p->email); ?></td>
                    <td class="px-4 py-2 text-gray-800 dark:text-gray-200"><?php echo e($p->pesan); ?></td>
                    <td class="px-4 py-2 text-center">
                        <form action="<?php echo e(route('admin.pesan.destroy', $p->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus pesan ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-800 font-semibold">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center py-4 text-gray-600 dark:text-gray-400">Belum ada pesan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-4">
        <?php echo e($pesan->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pari\Documents\Coding1\sdn4jatilaba\resources\views/admin/pesan/index.blade.php ENDPATH**/ ?>