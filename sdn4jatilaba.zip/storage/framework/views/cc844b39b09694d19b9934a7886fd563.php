<?php $__env->startSection('content'); ?>
<section class="py-10 px-4 max-w-7xl mx-auto">
    <h2 class="text-3xl font-bold text-center mb-10">Fasilitas Sekolah</h2>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <?php $__currentLoopData = $fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('pengunjung.fasilitas.show', $item->slug)); ?>" class="group block bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow hover:shadow-lg transition">
            <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" alt="<?php echo e($item->nama); ?>" class="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-300">
            <div class="p-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400">
                    <?php echo e($item->nama); ?>

                </h3>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pari\Documents\Coding1\sdn4jatilaba\resources\views/pengunjung/fasilitas/index.blade.php ENDPATH**/ ?>